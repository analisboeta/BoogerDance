package org.academniadecodigo.dancedance.stage;

/**
 * The available types of grids
 */
public enum StageType {

    SIMPLE_GFX

}
