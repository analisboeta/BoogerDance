package org.academniadecodigo.dancedance;

/**
 * Created by codecadet on 20/10/16.
 */
public interface RepresentableStage {

    /**
     * Initializes the stage
     */
    void init();

}
