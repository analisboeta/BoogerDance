package org.academniadecodigo.dancedance.gameobjects;


/**
 * Created by codecadet on 20/10/16.
 */
public interface RepresentableObject {

    public void setVisible(boolean visible);

}
